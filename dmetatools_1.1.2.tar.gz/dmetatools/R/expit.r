expit <- function(x) exp(x)/(1+exp(x))		# expit function
